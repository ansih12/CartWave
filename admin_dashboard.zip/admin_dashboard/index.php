<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart</title>
    <link rel="stylesheet" href="assets/styles.css">
    <!-- Add Firebase SDK -->
    <script src="https://www.gstatic.com/firebasejs/8.6.1/firebase-app.js"></script>
    <script src="https://www.gstatic.com/firebasejs/8.6.1/firebase-firestore.js"></script>
    <!-- Add html5-qrcode library -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html5-qrcode/2.3.8/html5-qrcode.min.js"
        integrity="sha512-r6rDA7W6ZeQhvl8S7yRVQUKVHdexq+GAlNkNNqVC7YyIV+NwqCTJe2hDWCiffTyRNOeGEzRRJ9ifvRm/HCzGYg=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
</head>

<body>
    <div class="container">
        <!-- QR Code Reader -->
        <div id="qr-reader" style="width:500px;"></div>
        <img id="scan_image" src="scan.png" alt="Scan QR Code" style="text-align: center;width: 100%;" />
        <button id="start-scan">Scan QR Code</button>

        <!-- Main System UI -->
        <div class="cart" id="cart-section" style="display: none;">
            <!-- Shopping Cart UI -->
            <div class="shopping-cart">

                <div class="content">
                    <div class="left-pane cart-header">
                        <div class="for-empty">
                            <h2>Your shopping cart is empty ..</h2>
                            <p>Start placing the products in your cart and they will appear here</p>
                            <!-- <button class="add-product">Fill the shopping cart</button> -->
                        </div>

                        <div class="cart-actions">
                            <button class="add-product" >Add Product</button>
                            <button class="detect-product" >Detect Product</button>
                        </div>

                        <div id="camera-feed"></div>


                        <div class="cart-items" style="display: none;">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Product</th>
                                        <th>Price</th>
                                        <th>Quantity</th>
                                        <th>Total</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="cart-table-body">
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="right-pane">
                        <img src="https://via.placeholder.com/200x150.png?text=Coming+Soon" alt="Coming Soon">
                        <div class="button-group">
                            <button class="type-barcode">TYPE BARCODE OR CHECK PRICE</button>
                            <button class="fruit-weight">FRUIT AND VEGETABLE WEIGHT</button>
                            <button class="pay-button pay" style="padding: 35px;font-size: 30px;">PAY</button>
                            <button class="cancel-button cancel" onclick="location.reload();">CANCEL</button>
                        </div>
                    </div>
                </div>
                <div class="summary">
                    <p>Subtotal: $<span id="subtotal">0.00</span></p>
                    <p>VAT: $<span id="vat">0.00</span></p>
                    <p>Total: $<span id="total">0.00</span></p>
                </div>
            </div>
        </div>

        <!-- Payment Modal -->
        <div id="paymentModal" class="modal" style="display:none;">
            <div class="modal-content" style="  max-width: 461px;">
                <h2>Preferred payment method</h2>
                <div class="payment-options">
                    <button class="pay-now">Pay with Saved Card</button>
                    <button class="pay-now">Pay with Wallet</button>
                </div>
                <p>Total to pay: $<span id="total-payment">0.00</span></p>
            </div>
        </div>

        <!-- Confirmation Modal -->
        <div id="confirmationModal" class="modal" style="display:none;">
            <div class="modal-content">
                <h2>Thank you!!!</h2>
                <p>Your payment is successful</p>
                <div class="confirmation-icon">
                    <img src="checkmark.png" alt="Success">
                </div>
                <button class="finish">Finish</button>
            </div>
        </div>
    </div>

    <!-- Product Modal -->
    <div id="productModal" class="modal" style="display:none; text-align: left;">
        <div class="modal-content" style="text-align: left;font-size: 16px;">
            <h2>Add Product</h2>
            <form id="productForm">
                <label for="productId">Product ID:</label>
                <input type="text" id="productId" required>
                <label for="productName">Product Name:</label>
                <input type="text" id="productName" required>
                <label for="productPrice">Product Price:</label>
                <input type="number" id="productPrice" step="0.01" required>
                <label for="productQuantity">Product Quantity:</label>
                <input type="number" id="productQuantity" min="1" required>
                <button type="submit" style="margin-top: 20px;padding: 10px 20px;border: 2px solid #21a956;background: none;color: #21a956;font-size: 16px;cursor: pointer;border-radius: 5px;">Add to Cart</button>
                <button type="button" class="close-modal" style="margin-top: 0;padding: 10px 20px;border: 2px solid #a92121;background: none;color: #a92121;font-size: 16px;cursor: pointer;border-radius: 5px;">Close</button>
            </form>
        </div>
    </div>

    <script src="assets/main.js"></script>
</body>

</html>