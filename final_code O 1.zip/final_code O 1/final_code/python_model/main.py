from flask_cors import CORS
from keras.models import load_model
from PIL import Image, ImageOps
from flask import Flask, request, jsonify
import numpy as np

# Load the Keras model and labels
model = load_model("keras_model.h5", compile=False)
class_names = [line.strip() for line in open("labels.txt").readlines()]

app = Flask(__name__)
CORS(app)  # This will enable CORS for all routes

@app.route("/predict", methods=["POST"])
def predict():
    try:
        print(request.files)
        # Check if the POST request has an image part
        if "image" not in request.files:
            return jsonify({"error": "No image part in the request"}), 400

        # Get the image file from the POST request
        image_file = request.files['image']
        image = Image.open(image_file).convert("RGB")

        # Resize the image to be at least 224x224 and then crop from the center
        size = (224, 224)
        image = ImageOps.fit(image, size, Image.Resampling.LANCZOS)

        # Convert the image to a numpy array
        image_array = np.asarray(image)

        # Normalize the image
        normalized_image_array = (image_array.astype(np.float32) / 127.5) - 1

        # Load the image into an array of the right shape to feed into the Keras model
        data = np.ndarray(shape=(1, 224, 224, 3), dtype=np.float32)
        data[0] = normalized_image_array

        # Perform prediction using your model
        prediction = model.predict(data)
        index = np.argmax(prediction)
        class_name = class_names[index]
        confidence_score = float(prediction[0][index])

        return jsonify({"class_name": class_name[2:], "confidence_score": confidence_score})

    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True)
