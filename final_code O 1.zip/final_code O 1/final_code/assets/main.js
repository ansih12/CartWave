// Your web app's Firebase configuration
var firebaseConfig = {
    apiKey: "AIzaSyBUHYNjtu5mWh_G5CYxyXgCA1xLqBLbhW4",
    authDomain: "supermarket-86fbc.firebaseapp.com",
    projectId: "supermarket-86fbc",
    storageBucket: "supermarket-86fbc.appspot.com",
    messagingSenderId: "931915320421",
    appId: "1:931915320421:web:7dda9635c4c03cc2c64a8c",
    measurementId: "G-L01H9P3XT5"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
var firestore = firebase.firestore();

// Reference to Firestore
var transactionsRef = firestore.collection('transactions');

// Event listeners
document.getElementById('start-scan').addEventListener('click', function () {
    startQrCodeScan();
});

document.querySelector('.add-product').addEventListener('click', function () {
    document.getElementById('productModal').style.display = 'flex';
});

document.querySelector('.close-modal').addEventListener('click', function () {
    document.getElementById('productModal').style.display = 'none';
});

document.querySelector('.detect-product').addEventListener('click', function () {
    detectProduct();
});

document.getElementById('productForm').addEventListener('submit', function (e) {
    e.preventDefault();
    addProductToCart();
    document.getElementById('productModal').style.display = 'none';
    updateCartVisibility();
});

document.querySelector('.pay').addEventListener('click', function () {
    document.getElementById('total-payment').textContent = document.getElementById('total').textContent;
    document.getElementById('paymentModal').style.display = 'flex';
});

document.querySelectorAll('.pay-now').forEach(button => {
    button.addEventListener('click', function () {
        handlePayment(this.textContent);
    });
});

document.querySelector('.finish').addEventListener('click', function () {
    document.getElementById('confirmationModal').style.display = 'none';
});

window.onclick = function (event) {
    closeModal(event);
}

// QR Code Scan
function startQrCodeScan() {
    document.getElementById('scan_image').style.display = 'none';

    const html5QrCode = new Html5Qrcode("qr-reader");

    html5QrCode.start(
        { facingMode: "environment" }, // Use rear camera
        {
            fps: 10, // Optional, frame per seconds for qr code scanning
            qrbox: { width: 250, height: 250 } // Optional, if you want bounded box UI
        },
        (decodedText, decodedResult) => {
            console.log(`Scan result: ${decodedText}`);
            localStorage.setItem('userId', decodedText); // Store user ID in localStorage
            alert('User ID captured: ' + decodedText);

            // Hide QR code reader and show the cart section
            html5QrCode.stop().then(() => {
                document.getElementById('qr-reader').style.display = 'none';
                document.getElementById('start-scan').style.display = 'none';
                document.getElementById('cart-section').style.display = 'block';
                updateCartVisibility();
                detectProduct();
            }).catch(err => {
                console.error('Failed to stop qr code reader: ', err);
            });
        },
        (errorMessage) => {
            // parse error, ignore it.
        })
        .catch(err => {
            // Start failed, handle it.
            console.error('Unable to start the QR code scanner: ', err);
        });

    document.getElementById('qr-reader').style.display = 'block';
}

// Function to detect product
function detectProduct() {
    const constraints = {
        video: true
    };

    navigator.mediaDevices.getUserMedia(constraints)
        .then((stream) => {
            const video = document.createElement('video');
            video.srcObject = stream;
            video.setAttribute('playsinline', ''); // Required for iOS Safari
            video.play();

            const cameraFeed = document.getElementById('camera-feed');
            cameraFeed.innerHTML = '';
            cameraFeed.appendChild(video);

            video.addEventListener('loadeddata', () => {
                const canvas = document.createElement('canvas');
                canvas.width = video.videoWidth;
                canvas.height = video.videoHeight;
                const context = canvas.getContext('2d');

                const updateCanvas = () => {
                    context.drawImage(video, 0, 0, canvas.width, canvas.height);
                    requestAnimationFrame(updateCanvas);
                };
                updateCanvas();

                cameraFeed.appendChild(canvas);

                const captureButton = document.createElement('button');
                captureButton.textContent = 'Capture Image';
                captureButton.addEventListener('click', () => {
                    // Draw the current video frame to the canvas
                    context.drawImage(video, 0, 0, canvas.width, canvas.height);
                    // Convert the canvas to a Blob
                    canvas.toBlob((blob) => {
                        sendToVisionAPI(blob);
                        // Stop video stream after capturing image
                        stream.getTracks().forEach(track => track.stop());
                    }, 'image/png');
                });
                cameraFeed.appendChild(captureButton);
            });
        })
        .catch((err) => {
            console.error('Error accessing camera: ', err);
            alert('Error accessing camera: ' + err.name + ' - ' + err.message);
        });
}

function sendToVisionAPI(imageBlob) {
    const formData = new FormData();
    formData.append('image', imageBlob, 'captured_image.png');

    fetch('http://127.0.0.1:5000/predict', {
        method: 'POST',
        body: formData
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            console.log(data);
            console.log(data['class_name']);
            if (data['class_name'] == 'nutella') {
                const productName = 'Nutella Hazelnut Spread with Chocolate, 350 g';
                const productPrice = 4.68;
                addDetectedProductToCart(productName, productPrice, 1);
            } else if (data['class_name'] == 'nesquik') {
                const productName = 'Nestle Nesquik Chocolate Breakfast Cereal, 325g';
                const productPrice = 30;
                addDetectedProductToCart(productName, productPrice, 1);
            }
        })
        .catch(error => {
            console.error('Error with Vision API: ', error);
        });
}




// function fetchProductInfo(productTitle) {
//     const apiUrl = `https://api.walmartlabs.com/v1/search?query=${encodeURIComponent(productTitle)}&format=json`;

//     fetch(apiUrl)
//         .then(response => response.json())
//         .then(data => {
//             console.log(data); // Process the data here (e.g., extract price)
//             if (data.items.length > 0) {
//                 const product = data.items[0];
//                 const productName = product.name;
//                 const productPrice = product.salePrice;
//                 console.log(`Product Name: ${productName}, Price: ${productPrice}`);
//                 return productPrice;
//                 // Process further as needed
//             } else {
//                 console.log(`No product found for "${productTitle}"`);
//                 return 10;
//             }
//         })
//         .catch(error => {
//             console.error('Error fetching product data:', error);
//         });
// }

function addDetectedProductToCart(name, price, quantity) {
    const cartTableBody = document.getElementById('cart-table-body');
    const row = cartTableBody.insertRow();

    const cell1 = row.insertCell(0);
    const cell2 = row.insertCell(1);
    const cell3 = row.insertCell(2);
    const cell4 = row.insertCell(3);
    const cell5 = row.insertCell(4);

    cell1.textContent = name;
    cell2.textContent = price.toFixed(2);
    cell3.innerHTML = `<input type="number" value="${quantity}" min="1" class="quantity">`;
    cell4.textContent = (price * quantity).toFixed(2);
    cell5.innerHTML = `<button class="remove-product">Remove</button>`;

    updateCartTotals();
    updateCartVisibility();

    cell3.querySelector('.quantity').addEventListener('change', function () {
        const newQuantity = parseInt(this.value);
        const newTotal = (price * newQuantity).toFixed(2);
        cell4.textContent = newTotal;
        updateCartTotals();
    });

    cell5.querySelector('.remove-product').addEventListener('click', function () {
        row.remove();
        updateCartTotals();
        updateCartVisibility();
    });
}

function addProductToCart() {
    const productId = document.getElementById('productId').value;
    const productName = document.getElementById('productName').value;
    const productPrice = parseFloat(document.getElementById('productPrice').value);
    const productQuantity = parseInt(document.getElementById('productQuantity').value);

    const cartTableBody = document.getElementById('cart-table-body');
    const row = cartTableBody.insertRow();

    const cell1 = row.insertCell(0);
    const cell2 = row.insertCell(1);
    const cell3 = row.insertCell(2);
    const cell4 = row.insertCell(3);
    const cell5 = row.insertCell(4);

    cell1.textContent = productName;
    cell2.textContent = productPrice.toFixed(2);
    cell3.innerHTML = `<input type="number" value="${productQuantity}" min="1" class="quantity">`;
    cell4.textContent = (productPrice * productQuantity).toFixed(2);
    cell5.innerHTML = `<button class="remove-product">Remove</button>`;

    updateCartTotals();

    cell3.querySelector('.quantity').addEventListener('change', function () {
        const newQuantity = parseInt(this.value);
        const newTotal = (productPrice * newQuantity).toFixed(2);
        cell4.textContent = newTotal;
        updateCartTotals();
    });

    cell5.querySelector('.remove-product').addEventListener('click', function () {
        row.remove();
        updateCartTotals();
        updateCartVisibility();
    });
}

function updateCartTotals() {
    let subtotal = 0;
    document.querySelectorAll('#cart-table-body tr').forEach(row => {
        const totalCell = row.cells[3];
        const total = parseFloat(totalCell.textContent);
        subtotal += total;
    });

    const vat = subtotal * 0.15; // Assuming VAT is 15%
    const total = subtotal + vat;

    document.getElementById('subtotal').textContent = subtotal.toFixed(2);
    document.getElementById('vat').textContent = vat.toFixed(2);
    document.getElementById('total').textContent = total.toFixed(2);
}

function calculateTotal() {
    return parseFloat(document.getElementById('total').textContent);
}

function clearCart() {
    const cartTableBody = document.getElementById('cart-table-body');
    while (cartTableBody.firstChild) {
        cartTableBody.removeChild(cartTableBody.firstChild);
    }
    updateCartTotals();
    updateCartVisibility();

    const cameraFeed = document.getElementById('camera-feed');
    cameraFeed.innerHTML = '';
}

function updateCartVisibility() {
    const cartTableBody = document.getElementById('cart-table-body');
    const cartHeader = document.querySelector('.cart-header');
    const cartFooter = document.querySelector('.summary');
    const cartItems = document.querySelector('.cart-items');
    const forEmpty = document.querySelector('.for-empty');

    if (cartTableBody.childElementCount === 0) {
        cartHeader.style.display = 'block';
        cartItems.style.display = 'none';
        cartFooter.style.display = 'none';
        forEmpty.style.display = 'block';

    } else {
        cartHeader.style.display = 'block';
        cartItems.style.display = 'block';
        cartFooter.style.display = 'flex';
        forEmpty.style.display = 'none';
    }
}

function handlePayment(paymentMethod) {
    const userId = localStorage.getItem('userId'); // Get user ID from localStorage
    if (!userId) {
        alert('User ID is not available.');
        return;
    }
    const amount = calculateTotal(); // Calculate total amount

    if (amount > 0) {
        console.log(paymentMethod);

        if (paymentMethod == 'Pay with Wallet') {
            handlePayWithWallet(userId, amount);
        } else {
            // Save the transaction
            saveTransaction(userId, amount, paymentMethod).then(() => {
                // Clear the cart after saving the transaction
                clearCart();
                document.getElementById('paymentModal').style.display = 'none';
                document.getElementById('confirmationModal').style.display = 'flex';
            }).catch(error => {
                alert('Failed to save transaction: ' + error.message);
            });
        }


    } else {
        alert('Please Add Products First!');
    }



}

// Function to save transaction to Firestore
function saveTransaction(userId, amount, paymentMethod) {
    const products = [];
    document.querySelectorAll('#cart-table-body tr').forEach(row => {
        const product = {
            name: row.cells[0].textContent,
            price: parseFloat(row.cells[1].textContent),
            quantity: parseInt(row.cells[2].querySelector('.quantity').value),
            total: parseFloat(row.cells[3].textContent)
        };
        products.push(product);
    });

    return transactionsRef.add({
        userId: userId,
        amount: amount,
        paymentMethod: paymentMethod,
        products: products,
        timestamp: firebase.firestore.FieldValue.serverTimestamp()
    });
}

function closeModal(event) {
    const paymentModal = document.getElementById('paymentModal');
    const confirmationModal = document.getElementById('confirmationModal');
    const productModal = document.getElementById('productModal');
    if (event.target == paymentModal) {
        paymentModal.style.display = 'none';
    }
    if (event.target == confirmationModal) {
        confirmationModal.style.display = 'none';
    }
    if (event.target == productModal) {
        productModal.style.display = 'none';
    }
}

async function handlePayWithWallet(userId, totalAmount) {

    try {
        const userDoc = await firestore.collection('users').doc(userId).get();
        if (userDoc.exists) {
            const userBalance = userDoc.data().balance ?? 0.0;

            if (userBalance >= totalAmount) {
                proceedWithPayment(userId, totalAmount, userBalance);
                // Save the transaction
                saveTransaction(userId, amount, paymentMethod).then(() => {
                    // Clear the cart after saving the transaction
                    clearCart();
                    document.getElementById('paymentModal').style.display = 'none';
                    document.getElementById('confirmationModal').style.display = 'flex';
                }).catch(error => {
                    alert('Failed to save transaction: ' + error.message);
                });
            } else {
                alert('Insufficient balance. Please top up your wallet.');
            }
        } else {
            alert('User not found.');
        }
    } catch (error) {
        console.error('Error fetching user data: ', error);
        alert('An error occurred. Please try again.');
    }
}


async function proceedWithPayment(userId, totalAmount, userBalance) {
    try {
        // Update the user's balance
        await firestore.collection('users').doc(userId).update({
            balance: userBalance - totalAmount
        });

        // Show confirmation modal
        document.getElementById('confirmationModal').style.display = 'block';
    } catch (error) {
        console.error('Error processing payment: ', error);
        alert('An error occurred. Please try again.');
    }
}
